const component=resolve=>require(['./index.vue'],resolve);
export default[
    {
        path:'/award',
        name:'award',
        component
    }
]
