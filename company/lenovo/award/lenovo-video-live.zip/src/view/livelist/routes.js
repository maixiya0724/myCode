const component=resolve=>require(['./index.vue'],resolve);
export default[
    {
        path:'/livelist',
        name:'livelist',
        component
    }]