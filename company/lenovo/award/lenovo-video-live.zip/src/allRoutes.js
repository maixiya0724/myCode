import modules_award from './view/award/routes.js';
import modules_live from './view/live/routes.js';
import modules_livelist from './view/livelist/routes.js';
export default [].concat(
    modules_award,
    modules_live,
    modules_livelist
);
