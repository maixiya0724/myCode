/**
 * Created by zhang on 2017/5/17.
 */
export default {
    getAwardDetail(id){
        return `/back/game/get/game/indexChannel/${id}?relativeId=47`
    },
}
