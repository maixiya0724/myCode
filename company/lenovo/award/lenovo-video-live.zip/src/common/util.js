/**
 * Created by zhang on 2017/8/1.
 */
console.log('环境 :===', process.env);
